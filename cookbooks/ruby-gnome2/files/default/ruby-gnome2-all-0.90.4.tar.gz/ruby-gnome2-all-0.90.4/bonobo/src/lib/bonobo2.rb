require 'gtk2'
require 'bonobo2.so'
