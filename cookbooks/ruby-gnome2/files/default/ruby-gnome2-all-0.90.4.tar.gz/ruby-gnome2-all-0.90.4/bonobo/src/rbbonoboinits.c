extern void   Init_bonobo_i18n();
extern void   Init_bonobo_main();
void Init_bonobo_inits()
{
   Init_bonobo_i18n();
   Init_bonobo_main();
}
