extern void   Init_bonobo_dock_band();
extern void   Init_bonobo_dock_item();
extern void   Init_bonobo_dock_layout();
extern void   Init_bonobo_dock();
extern void   Init_bonobo_ui_component();
extern void   Init_bonobo_ui_engine();
extern void   Init_bonobo_ui_main();
extern void   Init_bonobo_window();
void Init_bonoboui_inits()
{
   Init_bonobo_dock_band();
   Init_bonobo_dock_item();
   Init_bonobo_dock_layout();
   Init_bonobo_dock();
   Init_bonobo_ui_component();
   Init_bonobo_ui_engine();
   Init_bonobo_ui_main();
   Init_bonobo_window();
}
