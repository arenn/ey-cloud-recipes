require 'gnome2'
require 'bonoboui2.so'
